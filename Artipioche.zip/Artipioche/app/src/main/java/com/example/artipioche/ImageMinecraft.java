package com.example.artipioche;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.ImageButton;


public class ImageMinecraft extends AppCompatActivity {
    private MediaPlayer mediaPlayer;
    private ImageButton buttonImagePlay;
    private ImageButton buttonImageCreeper;
    private ImageButton buttonImageEnderdragon;
    private ImageButton buttonImageGhast;
    private ImageButton buttonImageWarden;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_minecraft);
        mediaPlayer = MediaPlayer.create(this,R.raw.sheep);
        buttonImagePlay = findViewById(R.id.buttonImagePlay);
        buttonImagePlay.setOnClickListener(view -> playMinecraft());

        buttonImageCreeper = findViewById(R.id.buttonImageCreeper);
        buttonImageCreeper.setOnClickListener(view -> pageGagnante());
        buttonImageEnderdragon = findViewById(R.id.buttonImageEnderdragon);
        buttonImageEnderdragon.setOnClickListener(view -> pagePerdante());
        buttonImageGhast = findViewById(R.id.buttonImageGhast);
        buttonImageGhast.setOnClickListener(view -> pagePerdante());
        buttonImageWarden = findViewById(R.id.buttonImageWarden);
        buttonImageWarden.setOnClickListener(view -> pagePerdante());


    }

    private void playMinecraft(){
        if(mediaPlayer != null){
            mediaPlayer.seekTo(100);
            mediaPlayer.start();
        }
    }

    protected void pageGagnante(){
        Intent intent = new Intent(this, SonText.class);
        intent.putExtra("score", "1");
        startActivity(intent);
    }
    protected void pagePerdante(){
        Intent intent = new Intent(this, SonText.class);
        intent.putExtra("score", "0");
        startActivity(intent);
    }

}