package com.example.artipioche;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class SonText extends AppCompatActivity {
    private Intent intent;

    private TextView textviewBonneReponse;
    private TextView textviewMauvaiseReponse;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_son_text);

        textviewBonneReponse = findViewById(R.id.textviewBonneReponse);
        textviewMauvaiseReponse = findViewById(R.id.textviewMauvaiseReponse);

        intent=getIntent();
        String score=intent.getStringExtra("score");
        if(score.equals("1")){
            textviewBonneReponse.setText("1");
            textviewMauvaiseReponse.setText("0");
        } else if (score.equals("0")) {
            textviewBonneReponse.setText("0");
            textviewMauvaiseReponse.setText("1");
        }
    }
}